# python -i disc02.py
def is_even(x):
    return x % 2 == 0


def keep_ints(cond, n):
    i = 1
    while i <= n:
        if cond(i):
            print(i)
        i += 1


def make_keeper(n):
    def h(cond):
        i = 1
        while i <= n:
            if cond(i):
                print(i)
            i += 1

    return h


y = 'y'
h = y


def y(y):
    h = 'h'
    if y == h:
        return y + 'i'
    y = lambda y: y(h)  # noqa
    return lambda h: y(h)


y = y(y)(y)


def print_delayed(x):
    def delay_print(y):
        print(x)
        return print_delayed(y)

    return delay_print


def print_n(n):
    def inner_print(x):
        if n <= 0:
            print("Done")
        else:
            print(x)
        return print_n(n - 1)

    return inner_print
