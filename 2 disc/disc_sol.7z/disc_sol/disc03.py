# Q1.1
def multiply(m, n):
    if n == 1:
        return m
    return m + multiply(m, n - 1)


# Q1.3
'''
steps = [1]
def hailstone(n):
    print(n)
    if n == 1:
        return steps[0]
    if n % 2:
        steps[0] += 1
        return hailstone(3 * n + 1)
    else:
        steps[0] += 1
        return hailstone(n // 2)
'''


def hailstone(n):
    print(n)
    if n == 1:
        return 1
    elif n % 2:
        return 1 + hailstone(3 * n + 1)
    else:
        return 1 + hailstone(n // 2)


print(hailstone(7))


# Q1.4
def merge(n1, n2):

    if n1 == 0:
        return n2
    elif n2 == 0:
        return n1
    elif n1 % 10 < n2 % 10:
        return merge(n1 // 10, n2) * 10 + n1 % 10
    else:
        return merge(n1, n2 // 10) * 10 + n2 % 10


# Q1.5
def make_func_repeater(f, x):
    def repeat(y):
        if y == 0:
            return x
            '''
        if y == 1:
            return f(x)
            '''
        else:
            return f(repeat(y - 1))

    return repeat


'''
incr_1 = make_func_repeater(lambda x: x + 1, 1)
incr_1(2)
print('R=', incr_1(5))
'''


# Q1.6
def is_prime(n):
    def prime_helper(x):
        if x == 0 or (x != 1 and n % x == 0):
            return False
        elif x == 1:
            return True
        else:
            return prime_helper(x - 1)

    return prime_helper(n - 1)


'''
def is_prime2(n):
    def prime_helper(x):
        if x == n:
            return True
        elif n % x == 0 or n == 1:
            return False
        else:
            return prime_helper(x + 1)

    return prime_helper(2)
'''
