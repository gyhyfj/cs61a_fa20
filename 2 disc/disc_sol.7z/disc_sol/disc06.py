# Q1.1
def memory(n):
    def f(g):
        nonlocal n
        n = g(n)
        return n
        # return n = g(n)SyntaxError

    return f


# Q2.2
def mystery(p, q):
    p[1].extend(q)
    q.append(p[1:])


p = [2, 3]
q = [4, [p]]
mystery(q, p)
# print(p,q)
