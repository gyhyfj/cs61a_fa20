# SICP Python 描述 中文版

原文：[CS61A: Online Textbook](http://www-inst.eecs.berkeley.edu/~cs61a/sp12/book/)

译者：[飞龙](https://github.com/wizardforcel)

+ [在线阅读](https://www.gitbook.com/book/wizardforcel/sicp-py/details)
+ [PDF格式](https://www.gitbook.com/download/pdf/book/wizardforcel/sicp-py)
+ [EPUB格式](https://www.gitbook.com/download/epub/book/wizardforcel/sicp-py)
+ [MOBI格式](https://www.gitbook.com/download/mobi/book/wizardforcel/sicp-py)
+ [Github](https://github.com/wizardforcel/sicp-py-zh)

## 赞助我

![](img/qr_alipay.png)

## 协议

[CC BY-NC-SA 4.0](http://creativecommons.org/licenses/by-nc-sa/4.0/)
